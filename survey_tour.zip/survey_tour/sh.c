#include<stdio.h>
#define MAX 65535
#define INTWORD unsigned short int

char name[19][10]={{"\\bigstar"}, {"M"},{"P"},{"28"},{"27"},{"26"},{"25"},
						{"N"},{"24"},{"20"},{"21"},{"23"},{"K"},{"22"},{"18"},
						{"17"},{"I"},{"16"},{"15"}};

inline void
array_inv(INTWORD start, INTWORD end, INTWORD n, INTWORD a[])
{
	INTWORD c,k,tmp;
	c = ((end < start) ? (n - start + end + 1) / 2 : (end - start + 1) / 2);
	for (k = 0; k < c; k++) {
		tmp = a[start];
		a[start] = a[end];
		a[end] = tmp;
		start = (start + 1) % n;
		if (end == 0)
			end = n - 1;
		else
			end = (end - 1) % n;
	}
}

inline INTWORD
array_min(INTWORD n, INTWORD a[])
{
	INTWORD i,m=a[0],k=0;
	for(i=1;i<n;i++){
		if(a[i]<m){
			m=a[i];
			k=i;
		}
	}
	return k;
}

void warshall(INTWORD n, INTWORD D[][n])
{
    INTWORD i, j, k;
    for (k = 0; k < n; k++) {
	for (i = 0; i < n; i++) {
	    if (D[i][k] == MAX)
		continue;
	    for (j = 0; j < n; j++) {
		if (D[i][j] - D[i][k] <= D[k][j])
		    continue;
		else
		    D[i][j] = D[i][k] + D[k][j];
	    }
	}
    }
}

INTWORD
init_cycle(INTWORD start, INTWORD n, INTWORD cycle[n], INTWORD D[][n])
{
    INTWORD i, j = n - 1, k, tmp, min, dis = 0;
    INTWORD a[n];
    for (i = 0; i < n; i++)
	a[i] = i;
    for (i = 0; i < n-1; i++, j--) {
	cycle[i] = a[start];
	//printf("%s\\to ", name[cycle[i]]);
	tmp = a[j];
	a[j] = a[start];
	a[start] = tmp;
	start = 0;
	min = D[a[j]][a[0]];
	for (k = 1; k < j; k++) {
	    if (D[a[j]][a[k]] < min) {
		start = k;
		min = D[a[j]][a[k]];
	    }
	}
	dis += D[a[j]][a[start]];
    }
    cycle[n-1]=a[0];
    dis += D[cycle[n - 1]][cycle[0]];
	//printf("%s ",name[cycle[n-1]]);
    //printf("dis=%d\n", dis);
    return dis;
}

INTWORD
two_opt(INTWORD n, INTWORD length, INTWORD cycle[n], INTWORD D[][n])
{
    //if(n<4)return length;
    INTWORD i, j, v, w, x, y, z;
  here:i = 0;
    while (i < n) {
	j = 0;
	while (j < n-3) {
	    v = (i + 1) % n;
	    w = (i + 2 + j) % n;
	    x = (w + 1) % n;
	    y = D[cycle[i]][cycle[v]] + D[cycle[w]][cycle[x]];
	    z = D[cycle[i]][cycle[w]] + D[cycle[v]][cycle[x]];
	    if (y <= z) {
		j += 1;
	    } else {
		//printf("%d %d\n", cycle[i], cycle[w]);
		length -= (y - z);
		//printf("%d\n",y-z);
		array_inv(v,w,n,cycle);
		/*for (i = 0; i < n; i++) {
			printf("%d ", cycle[i]);
		}
		printf("\n");*/
		goto here;
	    }
	}
	i += 1;
    }
    return length;
}

INTWORD
three_opt(INTWORD n, INTWORD length, INTWORD cycle[n], INTWORD D[][n])
{
    //if(n<6)return length;
    INTWORD i, j, k, v, w, t, u, x,l,scheme[4],s;
  here2:i = 0;
    while (i < n) {
	j = 0;
	v = (i + 1) % n;
	while (j < n - 5) {
	    k = 0;
	    w = (v + 1 + j) % n;
	    x = (w + 1) % n;
	    while (k < n - 5 - j) {
		t = (x + 1 + k) % n;
		u = (t + 1) % n;
		scheme[0] = D[cycle[i]][cycle[v]] + D[cycle[w]][cycle[x]] +
		    D[cycle[t]][cycle[u]];
		scheme[1] = D[cycle[i]][cycle[t]] + D[cycle[x]][cycle[v]] +
		    D[cycle[w]][cycle[u]];
		scheme[2] = D[cycle[i]][cycle[x]] + D[cycle[t]][cycle[v]] +
		    D[cycle[w]][cycle[u]];
		scheme[3] = D[cycle[i]][cycle[w]] + D[cycle[v]][cycle[t]] +
		    D[cycle[x]][cycle[u]];
		s=array_min(4,scheme);
		if (s == 0) {
		    k += 1;
		} else {
		  if(s==1){
		    //printf("%d %d %d\n", cycle[i], cycle[w], cycle[t]);
		    length -= (scheme[0] - scheme[1]);
		    //printf("%d\n", scheme[0] - scheme[1]);
		    array_inv(v,t,n,cycle);
		    l = ((t < x) ? (n - x + t + 1) : (t - x + 1) );
		    array_inv((v+l)%n,t,n,cycle);
		    /*for (i = 0; i < n; i++) {
			printf("%d ", cycle[i]);
		    }
		    printf("\n");*/
		  }
		    else if(s==2){
			    //printf("schm2 %d %d %d\n", cycle[i], cycle[w], cycle[t]);
			    length -= (scheme[0] - scheme[2]);
			    //printf("%d\n", scheme[0] - scheme[2]);
			    array_inv(v,w,n,cycle);
			    array_inv(x,t,n,cycle);
			    array_inv(v,t,n,cycle);
			    /*for (i = 0; i < n; i++) {
				    printf("%d ", cycle[i]);
			    }
			    printf("\n");*/
		    }
		    else{
			    //printf("schm3 %d %d %d\n", cycle[i], cycle[w], cycle[t]);
			    length -= (scheme[0] - scheme[3]);
			    //printf("%d\n", scheme[0] - scheme[3]);
			    array_inv(v,w,n,cycle);
			    array_inv(x,t,n,cycle);
			    /*for (i = 0; i < n; i++) {
				    printf("%d ", cycle[i]);
			    }
			    printf("\n");*/
		    }
		    goto here2;
		}
	    }
	    j += 1;
	}
	i += 1;
    }
    return length;
}

int main()
{
    INTWORD i, j, n;
    scanf("%d", &n);
    INTWORD D[n][n], init_length[n], cycle[n][n];
    for (i = 0; i < n; i++) {
	for (j = 0; j < n; j++)
	    scanf("%d", &D[i][j]);
    }
    warshall(n, D);
    /*for (i = 0; i < n; i++) {
	init_length[i] = init_cycle(i, n, cycle[i], D);
    }
    for (i = 0; i < n; i++) {
	    init_length[i] = two_opt(n, init_length[i], cycle[i], D);
	    printf("length[%d]=%d\n", i, init_length[i]);
    }
    for (i = 0; i < n; i++) {
	init_length[i] = three_opt(n, init_length[i], cycle[i], D);
	printf("length[%d]=%d\n", i, init_length[i]);
    }*/
    init_length[0]=init_cycle(0, n, cycle[0], D);
    init_length[0]=two_opt(n, init_length[0], cycle[0], D);
    printf("length[%d]=%d\n", 0, init_length[0]);
    init_length[0] = three_opt(n, init_length[0], cycle[0], D);
    printf("length[%d]=%d\n", 0, init_length[0]);
    for (i = 0; i < n; i++) {
	    printf("%s\\to ", name[cycle[0][i]]);
    }
    printf("\n");
    return 0;
}
