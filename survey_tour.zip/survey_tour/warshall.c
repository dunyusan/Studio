#include<stdio.h>
#define MAX 65535
int
main()
{
	int i,j,k,dis,n;
	scanf("%d",&n);
	int D[n][n]; 
	for(i=0;i<n;i++){
		for(j=0;j<n;j++)
			D[i][j]=MAX;
	}
	scanf("%d%d%d",&i,&j,&dis);
	while(i!=0){
		D[i-1][j-1]=dis;
		D[j-1][i-1]=dis;
		scanf("%d%d%d",&i,&j,&dis);
	}
	for(k=0;k<n;k++){
		for(i=0;i<n;i++){
			if(D[i][k]==MAX)continue;
			for(j=0;j<n;j++){
				if(D[i][j]-D[i][k]<=D[k][j])continue;
				else
					D[i][j]=D[i][k]+D[k][j];
			}
		}
	}
	printf("NAME: USIN\n");
	printf("TYPE: TSP\n");
	printf("COMMENT: GRAPH THEORY HOMEWORK\n");
	printf("DIMENSION: %d\n",n);
	printf("EDGE_WEIGHT_TYPE: EXPLICIT\n");
	printf("EDGE_WEIGHT_FORMAT: LOWER_DIAG_ROW\n");
	printf("EDGE_WEIGHT_SECTION\n");
	for(i=0;i<n;i++){
		//for(j=0;j<n;j++){
		for(j=0;j<=i;j++){
			if(i==j)
				printf("0\n");
				//printf("0 ");
			else{
				printf("%d ",D[i][j]);
			}
		}
		//printf("\n");
	}
	printf("EOF\n");
	return 0;
}
