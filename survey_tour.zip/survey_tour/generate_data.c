#include<stdio.h>
#define MAX 65535
int
main()
{
	int n,i,j,dis;
	scanf("%d",&n);
	int m[n][n];
	for(i=0;i<n;i++){
		for(j=0;j<n;j++)
			m[i][j]=MAX;
	}
	scanf("%d%d%d",&i,&j,&dis);
	while(i!=0){
		m[i-1][j-1]=dis;
		m[j-1][i-1]=dis;
		scanf("%d%d%d",&i,&j,&dis);
	}
	printf("%d\n",n);
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			if(i==j)
				printf("65535 ");
			else
				printf("%d ",m[i][j]);
		}
		printf("\n");
	}
	return 0;
}
