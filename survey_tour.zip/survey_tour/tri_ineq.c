#include<stdio.h>
int
main()
{
	int a[19][19],i,j,k;
	for(i=0;i<19;i++){
		for(j=0;j<19;j++){
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<19;i++){
		for(j=0;j<19;j++){
			if(j==i)continue;
			for(k=0;k<19;k++){
				if(k==i)continue;
				if(k==j)continue;
				if(a[i][k]>a[i][j]+a[j][k])
					printf("Not Satisfy!i=%d j=%d k=%d\n",i,j,k);
			}
		}
	}
	return 0;
}
