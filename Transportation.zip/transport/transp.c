#include<stdio.h>
#include<stdbool.h>
#include<string.h>

inline int min(int n, int *a)
{
    int i, m = 0;
    for (i = 1; i < n; i++) {
	if (a[i] < a[m])
	    m = i;
    }
    return m;
}

inline int max(int n, int *a)
{
    int i, m = 0;
    for (i = 1; i < n; i++) {
	if (a[i] > a[m])
	    m = i;
    }
    return m;
}

int min2(int n, int *a, int *m1)
{
    int i, m2;
    if (n == 1) {
	*m1 = 0;
	return 0;
    }
    if (a[0] <= a[1]) {
	*m1 = 0;
	m2 = a[1];
    } else {
	*m1 = 1;
	m2 = a[0];
    }
    for (i = 2; i < n; i++) {
	if (a[i] < a[*m1]) {
	    m2 = a[*m1];
	    *m1 = i;
	    continue;
	}
	if (a[i] < m2)
	    m2 = a[i];
    }
    return m2 - a[*m1];
}

void
initbase(int row, int col, int cost[][col], int quanchk[][col],
	 bool base[][col], int sell[], int prod[])
{
    int rowdif[row], coldif[col], rowtmp[col], coltmp[row];
    int roword[row], colord[col], rowmin[row], colmin[col];
    int i, j, rowm, colm;
    bool delrow = 0, delcol = 0;
    for (i = 0; i < row; i++)
	roword[i] = i;
    for (i = 0; i < col; i++)
	colord[i] = i;
    while (row + col > 1) {
	if (delrow == 0) {
	    for (i = 0; i < row; i++) {
		for (j = 0; j < col; j++) {
		    rowtmp[j] = cost[roword[i]][colord[j]];
		    //printf("%d!",rowtmp[j]);
		}
		rowdif[i] = min2(col, rowtmp, &rowmin[i]);
		//printf("%d;",rowdif[i]);
	    }
	}
	if (delcol == 0) {
	    for (i = 0; i < col; i++) {
		for (j = 0; j < row; j++) {
		    coltmp[j] = cost[roword[j]][colord[i]];
		    //printf("%d!",coltmp[j]);
		}
		coldif[i] = min2(row, coltmp, &colmin[i]);
		//printf("%d;",coldif[i]);
	    }
	}
	rowm = max(row, rowdif);
	colm = max(col, coldif);
	if (rowdif[rowm] > coldif[colm]) {
	    i = rowm;
	    j = rowmin[i];
	} else {
	    j = colm;
	    i = colmin[j];
	}
	base[roword[i]][colord[j]] = 1;
	if (sell[colord[j]] < prod[roword[i]]) {	//printf("if1\n");printf("(%d %d)\n",roword[i],colord[j]);
	    quanchk[roword[i]][colord[j]] = sell[colord[j]];
	    prod[roword[i]] -= sell[colord[j]];
	    sell[colord[j]] = 0;
	    coldif[j] = coldif[col - 1];
	    colmin[j] = colmin[col - 1];
	    colord[j] = colord[col - 1];
	    col -= 1;
	    delcol = 1;
	    delrow = 0;
	} else if (sell[colord[j]] == prod[roword[i]]) {	//printf("if2\n");printf("(%d %d)\n",roword[i],colord[j]);
	    quanchk[roword[i]][colord[j]] = sell[colord[j]];
	    sell[colord[j]] = prod[roword[i]] = 0;
	    if (col > 1) {
		quanchk[roword[i]][colord[(j + 1) % col]] = 0;
		base[roword[i]][colord[(j + 1) % col]] = 1;
	    } else if (row > 1) {
		quanchk[roword[(i + 1) % row]][colord[j]] = 0;
		base[roword[(i + 1) % row]][colord[j]] = 1;
	    } else {
	    }
	    coldif[j] = coldif[col - 1];
	    rowdif[i] = rowdif[row - 1];
	    colmin[j] = colmin[col - 1];
	    rowmin[i] = rowmin[row - 1];
	    colord[j] = colord[col - 1];
	    roword[i] = roword[row - 1];
	    row -= 1;
	    col -= 1;
	    delrow = delcol = 0;
	} else {		//printf("if3\n");printf("(%d %d)\n",roword[i],colord[j]);
	    quanchk[roword[i]][colord[j]] = prod[roword[i]];
	    sell[colord[j]] -= prod[roword[i]];
	    prod[roword[i]] = 0;
	    rowdif[i] = rowdif[row - 1];
	    rowmin[i] = rowmin[row - 1];
	    roword[i] = roword[row - 1];
	    row -= 1;
	    delrow = 1;
	    delcol = 0;
	}
    }
}

bool check(int row, int col, int cost[][col], int quanchk[][col],
	   bool base[][col], int *outi, int *outj)
{
    bool s;
    int i, j, su = 1, sv = 0;
    int uord[row], vord[col], un = row, vn = col, tmp, min = 0;
    int u[row], v[col];
    for (i = 0; i < row; i++)
	uord[i] = i;
    for (i = 0; i < col; i++)
	vord[i] = i;
    u[0] = 0;
    while (un + vn > 0) {
	if (s == 0) {
	    for (i = 0; i < su; i++) {
		for (j = 0; j < vn; j++) {
		    if (base[uord[i]][vord[j]] == 1) {
			v[vord[j]] = cost[uord[i]][vord[j]] - u[uord[i]];
			tmp = vord[j];
			vord[j] = vord[sv];
			vord[sv] = tmp;
			//printf("v[%d]=%d\n", vord[sv], v[vord[sv]]);
			sv += 1;
		    }
		}
		uord[i] = uord[un - i - 1];
	    }
	    un -= su;
	    su = 0;
	    s = 1;
	} else {
	    for (j = 0; j < sv; j++) {
		for (i = 0; i < un; i++) {
		    if (base[uord[i]][vord[j]] == 1) {
			u[uord[i]] = cost[uord[i]][vord[j]] - v[vord[j]];
			tmp = uord[i];
			uord[i] = uord[su];
			uord[su] = tmp;
			//printf("u[%d]=%d\n", uord[su], u[uord[su]]);
			su += 1;
		    }
		}
		vord[j] = vord[vn - j - 1];
	    }
	    vn -= sv;
	    sv = 0;
	    s = 0;
	}
    }
    /*printf("u=");
       for (i = 0; i < row; i++)
       printf("%d ", u[i]);
       printf("v=");
       for (i = 0; i < col; i++)
       printf("%d ", v[i]);
       printf("\n"); */
    for (i = 0; i < row; i++) {
	for (j = 0; j < col; j++) {
	    if (base[i][j] == 0) {
		quanchk[i][j] = cost[i][j] - u[i] - v[j];
		if (quanchk[i][j] < min) {
		    min = quanchk[i][j];
		    *outi = i;
		    *outj = j;
		}
	    }
	}
    }
    if (min < 0)
	return 1;
    else
	return 0;
}

void pivot(int row, int col, int quanchk[][col], bool base[][col],
	   int outi, int outj)
{
    int i, pos = 0;
    char from[row + col + 1], nf[row + col + 1], k, fi;
    int mi = outi, mj = outj, cycle[row + col][2];
    from[0] = 0;
    nf[0] = 4;
    cycle[0][0] = outi;
    cycle[0][1] = outj;
    for (i = 1; i < row + col; i++)
	nf[i] = 3;
    while (1) {
	if (pos == 0)
	    k = 4 - nf[0];
	else
	    k = (((from[pos] + 2) % 4) + 4 - nf[pos]) % 4;
	//printf("nf=%d, from=%d, k=%d\n",nf[pos],from[pos],k);
	for (fi = 0; nf[pos] > 0 && fi == 0; k = (k + 1) % 4, nf[pos] -= 1) {
	    if (k == 0) {
		for (i = 1; mi - i >= 0; i++) {
		    if ((mi - i) == outi && mj == outj)
			fi = 1;
		    if (base[mi - i][mj] == 1)
			fi = 2;
		    if (fi) {
			mi -= i;
			from[pos + 1] = 0;
			break;
		    }
		}
	    } else if (k == 1) {
		for (i = 1; mj + i < col; i++) {
		    if (mi == outi && (mj + i) == outj)
			fi = 1;
		    if (base[mi][mj + i] == 1)
			fi = 2;
		    if (fi) {
			mj += i;
			from[pos + 1] = 1;
			break;
		    }
		}
	    } else if (k == 2) {
		for (i = 1; mi + i < row; i++) {
		    if ((mi + i) == outi && mj == outj)
			fi = 1;
		    if (base[mi + i][mj] == 1)
			fi = 2;
		    if (fi) {
			mi += i;
			from[pos + 1] = 2;
			break;
		    }
		}
	    } else {
		for (i = 1; mj - i >= 0; i++) {
		    if (mi == outi && (mj - i) == outj)
			fi = 1;
		    if (base[mi][mj - i] == 1)
			fi = 2;
		    if (fi) {
			mj -= i;
			from[pos + 1] = 3;
			break;
		    }
		}
	    }
	}
	if (fi) {
	    if (fi == 1)
		break;
	    if (fi == 2) {
		pos += 1;
		cycle[pos][0] = mi;
		cycle[pos][1] = mj;
		//printf("(%d,%d)\n",mi,mj);
	    }
	} else {
	    nf[pos] = 3;
	    pos -= 1;
	    mi = cycle[pos][0];
	    mj = cycle[pos][1];
	}
    }
    int quan[(pos + 1) / 2], m;
    for (i = 1; i <= pos; i += 2)
	quan[i / 2] = quanchk[cycle[i][0]][cycle[i][1]];
    k = min((pos + 1) / 2, quan);
    m = quanchk[cycle[2 * k + 1][0]][cycle[2 * k + 1][1]];
    quanchk[outi][outj] = 0;
    for (i = 0; i <= pos; i += 2)
	quanchk[cycle[i][0]][cycle[i][1]] += m;
    for (i = 1; i <= pos; i += 2)
	quanchk[cycle[i][0]][cycle[i][1]] -= m;
    base[outi][outj] = 1;
    base[cycle[2 * k + 1][0]][cycle[2 * k + 1][1]] = 0;
}

int main()
{
    int i, j, m, n, outi, outj;
    scanf("%d%d", &m, &n);
    bool base[m][n];
    int cost[m][n], quanchk[m][n], sell[n], prod[m], mincost = 0;
    for (i = 0; i < m; i++)
	for (j = 0; j < n; j++)
	    scanf("%d", &cost[i][j]);
    for (i = 0; i < m; i++)
	scanf("%d", &prod[i]);
    for (i = 0; i < n; i++)
	scanf("%d", &sell[i]);
    for (i = 0; i < m; i++)
	bzero((bool *) base[i], n);
    initbase(m, n, cost, quanchk, base, sell, prod);
    while (check(m, n, cost, quanchk, base, &outi, &outj)) {
	pivot(m, n, quanchk, base, outi, outj);
    }
    for (i = 0; i < m; i++) {
	for (j = 0; j < n; j++) {
	    if (base[i][j] == 0)
		printf("# ");
	    //  else
	    //printf("%d ", quanchk[i][j]);
	    if (base[i][j] == 1) {
		mincost += (cost[i][j] * quanchk[i][j]);
		printf("%d ", quanchk[i][j]);
	    }
	}
	printf("\n");
    }
    printf("mincost=%d\n", mincost);
    return 0;
}
