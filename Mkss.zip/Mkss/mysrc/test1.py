#!/usr/bin/python

import mkss
import time

m=mkss.Mkss('lynn','192.168.11.47',20300,20,'192.168.11.47',20100)
while True:
    s=raw_input('#')
    if s=='quit':
        m.leave()
        print "Bye!"
        break
    m.search(s)
    time.sleep(1)
