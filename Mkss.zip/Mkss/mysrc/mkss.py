#!/usr/bin/python

import socket
import threading, Queue
import hashlib
import pchimera

def comb(kwset, num):
    '''Combination generator:Choose num keywords from kwset'''
    for i in range(len(kwset)):
        head = kwset[i:i+1]
        if num == 1:
            yield head
        else:
            rest = kwset[i+1:]
            for tail in comb(rest, num-1):
                yield head+tail

def myhash(term):
    '''My hash function:Return a 16-bit hex integer'''
    sha = hashlib.sha1()
    sha.update(term)
    return int(sha.hexdigest(), 16)

def mysum(kwset):
    '''My sum function:Calculate the kwset checksum'''
    keys=[myhash(term) for term in kwset]
    cksum = 0L
    maxint = int('1'+'0'*40, 16)
    for key in keys:
        cksum += key
        if cksum > maxint:
            cksum -= maxint
    return cksum

class Document(object):
    '''Encapsulate the document infomation'''
    def __init__(self):
        self.did = '-1'
        self.url = "douban"
        self.keyword_set = []
        self.rate = 5
    def add_keyword(self, keyword):
        self.keyword_set.append(keyword)

class Empty(Exception):
    '''No object infomation in Database'''
    def __init__(self):
        Exception.__init__(self)

class srch_handler(threading.Thread):
    '''Search handler'''
    def __init__(self, ndid, ndstat, rsc):
        self.ndid = ndid
        self.ndstat = ndstat
        self.sq = rsc['queue']['sq']
        self.crq = rsc['queue']['crq']
        self.rdq = rsc['queue']['rdq']
        self.db = rsc['db']
        threading.Thread.__init__(self)
        self.start()
    def check(self, query, an):
        ss = set([])
        for level in range(len(query)-1, 0, -1):
            for subquery in comb(query, level):
                if set(subquery).issubset(ss):
                    continue
                key = "%x" % mysum(subquery)
                if key in self.db:
                    ss |= set(subquery)
                    an[key] = (self.ndid, subquery)
                else:
                    cmsg = self.ndid+' '+'GIFO'+' '+'CK'+' '
                    pchimera.psend(self.ndstat, key, cmsg+' '.join(subquery)+'\0')
                    try:
                        cr = self.crq.get(timeout = 1)
                    except Queue.Empty:
                        print "Too slow!"
                        continue
                    if cr[1] == 'YES':
                        ss |= set(subquery)
                        an[key] = (cr[0], subquery)
                    else:
                        if len(subquery) == 1:
                            raise Empty()
                if ss == set(query): return
        raise Empty()
    def intersect(self, key, an):
        if not an:
            return None
        tmpdb = {}
        for k in an:
            if an[k][0] == self.ndid:
                tmpdb[k] = self.db[k]
            else:
                rmsg = self.ndid+' '+'GIFO'+' '+'DL'
                pchimera.psend(self.ndstat, k, rmsg+'\0')
                dl = self.rdq.get()
                tmpdb[k] = {}
                for d in dl:
                    doc = d.split(':')
                    tmpdb[k][doc[0]] = float(doc[1])
        self.db[key] = {}
        any = k
        s = set(tmpdb[k].keys())
        for k in tmpdb:
            if not k == any:
                s &= set(tmpdb[k].keys())
        for d in s:
            self.db[key][d] = tmpdb[any][d]
        return self.db[key]
    def run(self):
        try:
            while True:
                an = {}
                msg = self.sq.get()
                if msg == 'quit':
                    print "srch_handler quit!"
                    break
                print "Node %s SRCH Msg: %s" % (self.ndid, ' '.join(msg[2:]))
                try:
                    if msg[0] in self.db:
                        if len(self.db[msg[0]]) == 0:
                            raise Empty()
                    else:
                        if len(msg[2:]) == 1:
                            raise Empty()
                        else:
                            self.check(msg[2:], an)
                            if not self.intersect(msg[0], an):
                                raise Empty()
                    rmsg = self.ndid+' '+'RIFO'+' '+'FN'+' '
                    for i in self.db[msg[0]]:
                        rmsg += (i+':'+'%.2f'%self.db[msg[0]][i]+' ')
                    pchimera.psend(self.ndstat, msg[1], rmsg+'\0')
                except Empty:
                    self.db[msg[0]] = {}
                    print self.ndid, "reply for", msg
                    rmsg = self.ndid+' '+'RIFO'+' '+'FN'+' '+'NO'
                    pchimera.psend(self.ndstat, msg[1], rmsg+'\0')
        except:
            print "srch_handler fail!"

class gifo_handler(threading.Thread):
    '''Get infomation handler'''
    def __init__(self, ndid, ndstat, rsc):
        self.gq = rsc['queue']['gq']
        self.fbq = rsc['queue']['fbq']
        self.db = rsc['db']
        self.ndid = ndid
        self.ndstat = ndstat
        threading.Thread.__init__(self)
        self.start()
    def run(self):
        try:
            while True:
                msg = self.gq.get()
                if msg == 'quit':
                    print "chck_handler quit!"
                    break
                print "Node %s CHCK Msg: %s" % (self.ndid, ' '.join(msg[3:]))
                if msg[2] == 'CK':
                    if msg[0] in self.db:
                        rmsg = self.ndid+' '+'RIFO'+' '+'CK'+' '+'YES'
                    else:
                        rmsg = self.ndid+' '+'RIFO'+' '+'CK'+' '+'NO'
                        self.fbq.put(msg[0:1]+[self.ndid]+msg[3:])
                    pchimera.psend(self.ndstat, msg[1], rmsg+'\0')
                if msg[2] == 'DL':
                    rmsg = self.ndid+' '+'RIFO'+' '+'DL'+' '
                    if msg[0] in self.db:
                        for d in self.db[msg[0]]:
                            rmsg += (d+':'+'%.2f'%self.db[msg[0]][d]+' ')
                    pchimera.psend(self.ndstat, msg[1], rmsg+'\0')
        except:
            print "gifo_handler fail!"

class plsh_handler(threading.Thread):
    '''Publish infomation handler'''
    def __init__(self, ndid, ndstat, rsc):
        self.ndid = ndid
        self.ndstat = ndstat
        self.pq = rsc['queue']['pq']
        self.db = rsc['db']
        threading.Thread.__init__(self)
        self.start()
    def run(self):
        try:
            while True:
                msg = self.pq.get()
                if msg == 'quit':
                    print "plsh_handler quit!"
                    break
                if msg[0] not in self.db:
                    self.db[msg[0]] = {}
                self.db[msg[0]][msg[2]] = float(msg[4])
                print "Node %s PLSH Msg: %s" % (self.ndid, msg[5])
        except:
            print "plsh_handler fail!"

class Receiver(threading.Thread):
    '''Receiver module'''
    def __init__(self, rport, rq):
        pchimera.cvar.RPORT = rport
        self.port = rport
        self.rq = rq
        threading.Thread.__init__(self)
        self.start()
    def run(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.bind(('localhost', self.port))
        sock.listen(1024)
        try:
            while True:
                recvData = ""
                newSocket, address = sock.accept()
                while True:
                    tmp = newSocket.recv(2048)
                    if not tmp: break
                    recvData += tmp
                self.rq.put(recvData)
                if recvData == 'quit':
                    print "Receiver quit!"
                    newSocket.close()
                    break
                newSocket.close()
        finally:
            sock.close()

class Manager(object):
    '''Manager module'''
    def __init__(self):
        self.rsc = {}
        self.rq = Queue.Queue()
        self.imq = Queue.Queue()
        self.qty = ['sq', 'pq', 'gq', 'crq', 'rdq']
        self.psr = threading.Thread(target = self.parser)
        self.idx = threading.Thread(target = self.indexer)
        self.psr.start()
        self.idx.start()
    def addnode(self, ndid):
        self.rsc[ndid] = {'queue':{}, 'db':{}}
        for q in self.qty:
            self.rsc[ndid]['queue'][q] = Queue.Queue()
        self.rsc[ndid]['queue']['fbq'] = self.imq
        return self.rsc[ndid]
    def parser(self):
        while True:
            data = self.rq.get()
            if data == 'quit':
                print 'parser quit!'
                for nd in self.rsc:
                    self.rsc[nd]['queue']['sq'].put('quit')
                    self.rsc[nd]['queue']['pq'].put('quit')
                    self.rsc[nd]['queue']['gq'].put('quit')
                self.imq.put('quit')
                break
            msg = data.rstrip('\0').split()
            if msg[3] == 'SRCH':
                self.rsc[msg[0]]['queue']['sq'].put(msg[1:3]+msg[4:])
            elif msg[3] == 'GIFO':
                self.rsc[msg[0]]['queue']['gq'].put(msg[1:3]+msg[4:])
            elif msg[3] == 'PLSH':
                self.rsc[msg[0]]['queue']['pq'].put(msg[1:3]+msg[4:])
            elif msg[3] == 'RIFO':
                if msg[4] == 'CK':
                    self.rsc[msg[0]]['queue']['crq'].put(msg[2:3]+msg[5:])
                elif msg[4] == 'DL':
                    self.rsc[msg[0]]['queue']['rdq'].put(msg[5:])
                elif msg[4] == 'FN':
                    print "FINAL Result:", msg
            else:
                print msg
    def indexer(self):
        while True:
            mi = self.imq.get()
            if mi == 'quit':
                print "indexer quit!"
                break
            print "Node", mi[1], "wanna index keyword-set:", mi[2:]
            self.rsc[mi[1]]['queue']['sq'].put(mi)

class Handler(object):
    '''Handler module'''
    def __init__(self):
        self.hdr = {}
    def addnode(self, ndid, ndstat, rsc):
        self.hdr[ndid] = {}
        self.hdr[ndid]['sh'] = srch_handler(ndid, ndstat, rsc)
        self.hdr[ndid]['ph'] = plsh_handler(ndid, ndstat, rsc)
        self.hdr[ndid]['gh'] = gifo_handler(ndid, ndstat, rsc)

class Mkss(object):
    '''Multi-Keyword Search System'''
    def __init__(self, username, hostname, port, nodenum, jhost = "", jport = 0):
        self.nodes = {}
        self.manager = Manager()
        self.handler = Handler()
        self.rport = port+nodenum
        self.receiver = Receiver(self.rport, self.manager.rq)
        sha = hashlib.sha1()
        sha.update(username)
        nd = sha.hexdigest()
        print nd
        self.fnd = nd
        self.nodes[nd] = pchimera.pjoin(jhost, jport, nd, port)
        rsc = self.manager.addnode(nd)
        self.handler.addnode(nd, self.nodes[nd], rsc)
        for i in range(1, nodenum):
            sha.update(username)
            nd = sha.hexdigest()
            print nd
            self.nodes[nd] = pchimera.pjoin(hostname, port, nd, port+i)
            rsc = self.manager.addnode(nd)
            self.handler.addnode(nd, self.nodes[nd], rsc)
        print "%s successfully join Usearch!" % username

    def search(self, query):
        keyword_set = query.split()
        key = "%x" % mysum(keyword_set)
        print "Mid:query key is %s" % key
        smsg = [self.fnd, 'SRCH']
        smsg += keyword_set
        pchimera.psend(self.nodes[self.fnd], key, ' '.join(smsg)+'\0')
    
    def publish(self, doc):
        for k in doc.keyword_set:
            key = "%x" % myhash(k)
            pmsg = [self.fnd, 'PLSH', doc.did, doc.url, "%d" % doc.rate, k]
            pchimera.psend(self.nodes[self.fnd], key, ' '.join(pmsg)+'\0')

    def neighbors(self):
        pchimera.pneighbors(self.nodes[self.fnd])

    def leave(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect(('localhost', self.rport))
        s.sendall('quit')
        s.close()
