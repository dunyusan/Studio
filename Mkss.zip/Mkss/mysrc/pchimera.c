/*
 * Usin Y. S. Deng (dunyusan@126.com)
*/
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "chimera.h"
#include "network.h"
#include "route.h"

#define MKSS 18
int RPORT = 123456;

void fatal(char *string)
{
    fprintf(stderr, "%s\n", string);
    exit(1);
}

void deliver(ChimeraState * state, Key * k, Message * m)
{
    int c, sock;
    struct sockaddr_in channel;
    struct hostent *h;
    char str[NETWORK_PACK_SIZE];	//Caution!
    if (m->type != MKSS)
	return;
    h = gethostbyname("localhost\0");
    if (!h)
	fatal("gethostbyname failed");
    sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (sock < 0)
	fatal("socket");
    memset(&channel, 0, sizeof(channel));
    channel.sin_family = AF_INET;
    memcpy(&channel.sin_addr.s_addr, h->h_addr, h->h_length);
    channel.sin_port = htons(RPORT);
    c = connect(sock, (struct sockaddr *) &channel, sizeof(channel));
    if (c < 0)
	fatal("connect failed");
    sprintf(str, "%s %s %s",
	    ((ChimeraGlobal *) state->chimera)->me->key.keystr, k->keystr,
	    m->payload);
    write(sock, str, strlen(str) + 1);
    close(sock);
}

void update(ChimeraState * state, Key * k, ChimeraHost * h, int joined)
{
    int c, sock;
    char jl[3];
    struct sockaddr_in channel;
    struct hostent *hn;
    char str[256];
    if (joined)
	strcpy(jl,"JN");
    else
	strcpy(jl,"LV");
    hn = gethostbyname("localhost\0");
    if (!hn)
	fatal("gethostbyname failed");
    sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (sock < 0)
	fatal("socket");
    memset(&channel, 0, sizeof(channel));
    channel.sin_family = AF_INET;
    memcpy(&channel.sin_addr.s_addr, hn->h_addr, hn->h_length);
    channel.sin_port = htons(RPORT);
    c = connect(sock, (struct sockaddr *) &channel, sizeof(channel));
    if (c < 0)
	fatal("connect failed");
    sprintf(str, "%s : UPDT %s %s:%s:%d",
	    ((ChimeraGlobal *) state->chimera)->me->key.keystr, jl,
	    k->keystr, h->name, h->port);
    write(sock, str, strlen(str) + 1);
    close(sock);
}

ChimeraState *pjoin(char *joinhost, int joinport, char *nodeid, int port)
{
    ChimeraHost *host = NULL;
    Key keyinput;
    ChimeraState *state;
    str_to_key(nodeid, &keyinput);
    state = chimera_init(port);
    if (state == NULL)
	fatal("unable to initialize chimera \n");
    if (strcmp(joinhost, "")) {
	host = host_get(state, joinhost, joinport);
    }
    chimera_deliver(state, deliver);
    //chimera_update(state, update);
    chimera_setkey(state, keyinput);
    chimera_register(state, MKSS, 1);
    chimera_join(state, host);
    return (state);

}

void psend(ChimeraState * state, char *dest, char *msg)
{
    Key key;
    str_to_key(dest, &key);
    chimera_send(state, key, MKSS, strlen(msg) + 1, msg);
}

void pneighbors(ChimeraState * state)
{
    int i, c, sock;
    struct sockaddr_in channel;
    struct hostent *h;
    char str[512];
    ChimeraHost **leafset;
    h = gethostbyname("localhost\0");
    if (!h)
	fatal("gethostbyname failed");
    sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (sock < 0)
	fatal("socket");
    memset(&channel, 0, sizeof(channel));
    channel.sin_family = AF_INET;
    memcpy(&channel.sin_addr.s_addr, h->h_addr, h->h_length);
    channel.sin_port = htons(RPORT);
    c = connect(sock, (struct sockaddr *) &channel, sizeof(channel));
    if (c < 0)
	fatal("connect failed");
    strcpy(str, ((ChimeraGlobal *) state->chimera)->me->key.keystr);
    strcat(str, " : NGBR ");
    leafset = route_neighbors(state, LEAFSET_SIZE);
    for (i = 0; leafset[i] != NULL; i++) {
	strcat(str, leafset[i]->key.keystr);
	strcat(str, " ");
    }
    write(sock, str, strlen(str) + 1);
    close(sock);
}
