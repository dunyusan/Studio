#!/usr/bin/python

import mkss
import time

m=mkss.Mkss('yushan','192.168.11.47',20100,5)
while True:
    s=raw_input('#')
    if s=='quit':
        m.leave()
        print "Bye!"
        break
    elif s=='plsh':
        doc=mkss.Document()
        doc.did=raw_input("id:")
        term=raw_input("keywords:")
        doc.keyword_set=term.split()
        m.publish(doc)
    elif s=='ngbr':
        m.neighbors()
    else:
        m.search(s)
        time.sleep(1)
