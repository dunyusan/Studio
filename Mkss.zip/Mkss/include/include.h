#ifndef _INCLUDE_H_
#define _INCLUDE_H_


#define TRUE 1
#define FALSE 0

typedef int Bool;


#endif /* _INCLUDE_H_ */
