#include<stdio.h>
#include<stdlib.h>
#include<math.h>

//#define EPSILON 0.00000000001
#define EPSILON 1e-16
#define MAXNUM 65535

void swap_doub(double *a, double *b)
{
    double tmp;
    tmp = *a;
    *a = *b;
    *b = tmp;
}

void swap_int(int *a, int *b)
{
    int tmp;
    tmp = *a;
    *a = *b;
    *b = tmp;
}


int fabs_max(int n, double array[])
{
    int i, m = 0;
    double tmp = fabs(array[0]);
    for (i = 1; i < n; i++) {
	if (fabs(array[i]) > tmp) {
	    tmp = fabs(array[i]);
	    m = i;
	}
    }
    return m;
}

int max(int n, double array[])
{
    int i, m = 0;
    double tmp = array[0];
    for (i = 1; i < n; i++) {
	if (array[i] > tmp) {
	    tmp = array[i];
	    m = i;
	}
    }
    return m;
}

void init_array(int n, int array[])
{
    int i;
    for (i = 0; i < n; i++)
	array[i] = i;
}

void init_matrix(int n, double A[][n])
{
    int i, j;
    for (i = 0; i < n; i++) {
	for (j = 0; j < n; A[i][j] = 0.0, j++);
    }
}

void identy_matrix(int n, double A[][n])
{
    int i;
    init_matrix(n, A);
    for (i = 0; i < n; A[i][i] = 1.0, i++);
}

double xxT(int n, double x[])
{
    int i;
    double sum;
    for (i = 0, sum = 0.0; i < n; i++)
	sum += x[i] * x[i];
    return sum;
}

double norm2(int n, double x[])
{
    return sqrt(xxT(n,x));
}

void transpose(int m, int n, double A[m][n], double At[n][m])
{
    int i, j;
    for (i = 0; i < n; i++)
	for (j = 0; j < m; j++)
	    At[i][j] = A[j][i];
}

void hilb(int n,double H[n][n])
{
	int i,j;
	for(i=0;i<n;i++){
		for(j=i;j<n;j++)
			H[i][j]=H[j][i]=((double)1)/((double)(i+j+1));
	}
}

void printmat(int n, double A[][n], int pos[])
{
    int i, j;
    for (i = 0; i < n; i++) {
	printf("| ");
	for (j = 0; j < n; j++) {
	    printf("%9.6f ", A[pos[i]][j]);
	}
	printf("|\n");
    }
}

void print_doub_array(int n, double array[], int pos[])
{
    int i;
    printf("[ ");
    for (i = 0; i < n; i++)
	printf("%9.6f ", array[pos[i]]);
    printf("]\n");
}

void print_int_array(int n, int array[])
{
    int i;
    printf("[ ");
    for (i = 0; i < n; i++)
	printf("%5d ", array[i]);
    printf("]\n");
}
