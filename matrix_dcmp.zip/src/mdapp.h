#include "nr.h"

int ludcmp(int n, double A[][n], int pos[])
{
    int i, j, k, i_k;
    double sum, s[n];
    for (j = 0; j < n; j++) {
	for (i = 0; i < j; i++) {
	    for (k = 0, sum = 0.0; k < i; k++)
		sum += A[pos[i]][k] * A[pos[k]][j];
	    A[pos[i]][j] -= sum;
	    s[i] = 0;
	}
	for (i = j; i < n; i++) {
	    for (k = 0, sum = 0.0; k < j; k++)
		sum += A[pos[i]][k] * A[pos[k]][j];
	    s[i] = A[pos[i]][j] - sum;
	}
	i_k = fabs_max(n, s);
	if (s[i_k] == 0.0) {
	    printf("Singular Matrix in LUdcmp\n");
	    return -1;
	}
	if (i_k != j) {
	    swap_doub(&s[j], &s[i_k]);
	    swap_int(&pos[j], &pos[i_k]);
	}
	A[pos[j]][j] = s[j];
	for (i = j + 1; i < n; i++)
	    A[pos[i]][j] = s[i] / s[j];
    }
    return 0;
}

void lubksb(int n, double A[][n], double x[], double b[], int pos[])
{
    int i, k;
    double sum;
    for (i = 0; i < n; i++) {
	for (k = 0, sum = 0.0; k < i; k++)
	    sum += A[pos[i]][k] * x[k];
	x[i] = b[pos[i]] - sum;
    }
    for (i = n - 1; i >= 0; i--) {
	for (k = i + 1, sum = 0.0; k < n; k++)
	    sum += A[pos[i]][k] * x[k];
	x[i] = (x[i] - sum) / A[pos[i]][i];
    }
}

void ludcmp_tridiag(int n, double A[][n])
{
    int i;
    for (i = 1; i < n; i++) {
	A[2][i] = A[2][i] / A[1][i - 1];
	A[1][i] = A[1][i] - A[2][i] * A[0][i - 1];
    }
}

void thomas(int n, double A[][n], double x[], double d[])
{
    int i;
    ludcmp_tridiag(n, A);
    x[0] = d[0];
    for (i = 1; i < n; i++)
	x[i] = d[i] - A[2][i] * x[i - 1];
    x[n - 1] = x[n - 1] / A[1][n - 1];
    for (i = n - 2; i >= 0; i--)
	x[i] = (x[i] - A[0][i] * x[i + 1]) / A[1][i];
}

int Chodcmp(int n, double A[][n])
{
    int i, j, k;
    double sum;
    for (j = 0; j < n; j++) {
	for (k = 0, sum = 0.0; k < j; k++)
	    sum += A[j][k] * A[j][k];
	A[j][j] -= sum;
	if (A[j][j] == 0.0) {
	    printf("A Is Not Positive Definite!\n");
	    return -1;
	}
	A[j][j] = sqrt(A[j][j]);
	for (i = j + 1; i < n; i++) {
	    for (k = 0, sum = 0.0; k < j; k++)
		sum += A[i][k] * A[j][k];
	    A[i][j] = (A[i][j] - sum) / A[j][j];
	    A[j][i] = A[i][j];
	}
    }
    return 0;
}

void householder(int n, int k, double u[], double *beta, double x[])
{				//Px saved in x[].
    int i, j;
    double length;
    length = norm2(n - k, &x[k]);
    if (length == 0 || length == fabs(x[k]))
	goto end;
    u[k] = (x[k] >= 0) ? (x[k] + length) : (x[k] - length);
    for (i = k + 1; i < n; i++)
	u[i] = x[i];
    *beta = 1 / (length * (length + fabs(x[k])));
    x[k] = x[k] - u[k];
    for (i = k + 1; i < n; x[i] = 0, i++);
  end:;
}

void qrdcmp(int m, int n, double A[m][n], double Q[m][m])
{				//R saved in A.
    int i, j, k, min;
    double At[n][m], Qt[m][m], u[m], beta, tmp;
    transpose(m, n, A, At);
    min = (m >= n) ? n : m;
    identy_matrix(m, Qt);
    for (k = 0; k < min - 1; k++) {
	householder(m, k, u, &beta, At[k]);
	for (j = 0; j < m; j++) {
	    for (i = k, tmp = 0.0; i < m; i++)
		tmp += u[i] * Qt[i][j];
	    tmp *= beta;
	    for (i = k; i < m; i++)
		Qt[i][j] -= tmp * u[i];
	}
	for (j = k + 1; j < n; j++) {
	    for (i = k, tmp = 0.0; i < m; i++)
		tmp += u[i] * At[j][i];
	    tmp *= beta;
	    for (i = k; i < m; i++)
		At[j][i] -= tmp * u[i];
	}
    }
    transpose(n, m, At, A);
    transpose(m, m, Qt, Q);
}

int
qrdcmp_with_pivot(int m, int n, double A[m][n], double Q[m][m], int pos[])
{
    int i, j, k, min, p, rank = 0;
    double At[n][m], Qt[m][m], u[m], beta, tmp, temp[n];
    init_array(n, pos);
    transpose(m, n, A, At);
    min = (m >= n) ? n : m;
    identy_matrix(m, Qt);
    for (j = 0; j < n; j++) {
	temp[j] = xxT(m, At[j]);
    }
    p = max(m, temp);
    if (temp[p] < EPSILON)
	return rank;
    swap_int(&pos[0], &pos[p]);
    swap_doub(&temp[0], &temp[p]);
    for (k = 0; k < min - 1; k++) {
	householder(m, k, u, &beta, At[pos[k]]);
	for (j = 0; j < m; j++) {
	    for (i = k, tmp = 0.0; i < m; i++)
		tmp += u[i] * Qt[i][j];
	    tmp *= beta;
	    for (i = k; i < m; i++)
		Qt[i][j] -= tmp * u[i];
	}
	for (j = k + 1; j < n; j++) {
	    for (i = k, tmp = 0.0; i < m; i++)
		tmp += u[i] * At[pos[j]][i];
	    tmp *= beta;
	    for (i = k; i < m; i++)
		At[pos[j]][i] -= tmp * u[i];
	}
	for (j = k + 1; j < n; j++) {
	    temp[j] -= At[pos[j]][k] * At[pos[j]][k];
	}
	p = max(m - k - 1, &temp[k + 1]);
	if (temp[p + k + 1] < EPSILON) {
	    rank = k + 1;
	    break;
	}
	swap_int(&pos[k + 1], &pos[p + k + 1]);
	swap_doub(&temp[k + 1], &temp[p + k + 1]);
    }
    if (rank == 0)
	rank = min;
    transpose(n, m, At, A);
    transpose(m, m, Qt, Q);
    printf("rank=%d\n", rank);
    return rank;
}

void givens(double x_i, double x_k, double cs[])
{
    if (x_k == 0) {
	cs[0] = 1;
	cs[1] = 0;
    } else {
	double t;
	if (fabs(x_k) >= fabs(x_i)) {
	    t = x_i / x_k;
	    cs[1] = 1 / sqrt(1 + t * t);
	    cs[0] = cs[1] * t;
	    if (x_k < 0) {
		cs[0] = -cs[0];
		cs[1] = -cs[1];
	    }
	} else {
	    t = x_k / x_i;
	    cs[0] = 1 / sqrt(1 + t * t);
	    cs[1] = cs[0] * t;
	    if (x_i < 0) {
		cs[0] = -cs[0];
		cs[1] = -cs[1];
	    }
	}
    }
}

void qrupdt(int m, int n, double Q[][m], double R[m][n], double s[],
	    double t[])
{
    int i, j, k, l, pos[3];
    double u[m], cs[2], tmp;
    for (j = 0; j < m; j++) {
	for (i = 0, u[j] = 0.0; i < m; i++)
	    u[j] += Q[i][j] * s[i];
    }
    for (k = m - 1; k >= 0; k--) {
	if (u[k] != 0.0)
	    break;
    }
    if (k < 0)
	k = 0;
    for (i = k - 1; i >= 0; i--) {
	givens(u[i], u[i + 1], cs);
	u[i] = cs[0] * u[i] + cs[1] * u[i + 1];
	u[i + 1] = 0.0;
	for (j = i; j < n; j++) {
	    tmp = cs[0] * R[i][j] + cs[1] * R[i + 1][j];
	    R[i + 1][j] = cs[0] * R[i + 1][j] - cs[1] * R[i][j];
	    R[i][j] = tmp;
	}
	for (j = 0; j < m; j++) {
	    tmp = cs[0] * Q[j][i] + cs[1] * Q[j][i + 1];
	    Q[j][i + 1] = cs[0] * Q[j][i + 1] - cs[1] * Q[j][i];
	    Q[j][i] = tmp;
	}
	if (u[i] == 0.0)
	    i -= 1;
    }
    for (i = 0; i < m; i++) {
	for (j = 0; j < n; j++)
	    R[i][j] += u[i] * t[j];
    }
    for (i = 0; i < n - 1; i++) {
	if (R[i + 1][i] == 0.0)
	    continue;
	givens(R[i][i], R[i + 1][i], cs);
	for (j = i; j < n; j++) {
	    tmp = cs[0] * R[i][j] + cs[1] * R[i + 1][j];
	    R[i + 1][j] = cs[0] * R[i + 1][j] - cs[1] * R[i][j];
	    R[i][j] = tmp;
	}
	for (j = 0; j < m; j++) {
	    tmp = cs[0] * Q[j][i] + cs[1] * Q[j][i + 1];
	    Q[j][i + 1] = cs[0] * Q[j][i + 1] - cs[1] * Q[j][i];
	    Q[j][i] = tmp;
	}
    }
}

void jacobi(int n, double A[][n], double V[][n], double ev[])
{
    int i, j, k, noi = 0;
    double tau, c, s, t, off = 0.0, alpha = 0.0, tmp1, tmp2;
    identy_matrix(n, V);
    for (i = 0; i < n - 1; i++) {
	for (j = i + 1; j < n; j++) {
	    off += 2 * A[i][j] * A[i][j];
	}
    }
    alpha = sqrt(off);
    while (off > EPSILON && noi < MAXNUM) {
	alpha = alpha / n;
	for (i = 0; i < n - 1; i++) {
	    for (j = i + 1; j < n; j++) {
		if (fabs(A[i][j]) >= alpha) {
		    tau = (A[i][i] - A[j][j]) / (2 * A[i][j]);
		    if (tau >= 0)
			t = 1 / (fabs(tau) + sqrt(1 + tau * tau));
		    else
			t = -1 / (fabs(tau) + sqrt(1 + tau * tau));
		    c = 1 / sqrt(1 + t * t);
		    s = t * c;
		    for (k = 0; k < n; k++) {
			if (k != i && k != j) {
			    tmp1 = c * A[k][i] + s * A[k][j];
			    tmp2 = c * A[k][j] - s * A[k][i];
			    A[k][i] = A[i][k] = tmp1;
			    A[k][j] = A[j][k] = tmp2;
			}
		    }
		    A[i][i] = A[i][i] + t * A[i][j];
		    A[j][j] = A[j][j] - t * A[i][j];
		    off -= 2 * A[i][j] * A[i][j];
		    A[i][j] = A[j][i] = 0.0;
		    for (k = 0; k < n; k++) {
			tmp1 = c * V[k][i] + s * V[k][j];
			tmp2 = -s * V[k][i] + c * V[k][j];
			V[k][i] = tmp1;
			V[k][j] = tmp2;
		    }
		}
	    }
	}
	noi += 1;
    }
    if (noi == MAXNUM)
	printf("So Many Iterations! More Than MAXNUM!\n");
    for (i = 0; i < n; i++)
	ev[i] = A[i][i];
}

void eigsrt(int n, double ev[], int ord[])
{
    int i, m;
    init_array(n, ord);
    for (i = 0; i < n - 1; i++) {
	m = max(n - i, &ev[i]);
	swap_int(&ord[i], &ord[m + i]);
	swap_doub(&ev[i], &ev[m + i]);
    }
}

int
svd(int m, int n, double A[m][n], double U[][m], double V[][n],
    double sv[n])
{
    int i, j, k, rank, ord[n];
    double Vt[n][n], AtA[n][n], tmp[n];
    for (i = 0; i < n; i++) {
	for (j = i; j < n; j++) {
	    for (k = 0, tmp[j] = 0.0; k < m; k++)
		tmp[j] += A[k][i] * A[k][j];
	}
	for (j = i; j < m; j++)
	    AtA[j][i] = AtA[i][j] = tmp[j];
    }
    jacobi(n, AtA, Vt, sv);
    eigsrt(n, sv, ord);
    for (i = 0; i < n; i++)
	sv[i] = sqrt(sv[i]);
    k = m > n ? m : n;
    rank = 0;
    while (rank < n) {		//calculate numerical rank.
	if (sv[rank] > sv[0] * k * EPSILON)
	    rank += 1;
	else
	    break;
    }
    for (j = 0; j < n; j++) {
	for (i = 0; i < n; i++)
	    V[i][j] = Vt[i][ord[j]];
    }
    for (j = 0; j < rank; j++) {
	for (i = 0; i < m; i++) {
	    for (k = 0, U[i][j] = 0.0; k < n; k++)
		U[i][j] += A[i][k] * V[k][j];
	    U[i][j] = U[i][j] / sv[j];
	}
    }
    for (j = rank; j < m; j++) {
	for (i = 0; i < m; i++)
	    U[i][j] = 0.0;
    }
    return rank;
}

void
svbksb(int m, int n, int rank, double U[][m], double V[][n],
       double b[], double sv[], double x[])
{
    int i, j;
    double tmp[rank];
    for (i = 0; i < rank; i++) {
	for (j = 0, tmp[i] = 0.0; j < m; j++)
	    tmp[i] += U[j][i] * b[j];
	tmp[i] = tmp[i] / sv[i];
    }
    for (i = 0; i < n; i++) {
	for (j = 0, x[i] = 0.0; j < rank; j++)
	    x[i] += V[i][j] * tmp[j];
    }
}
