#include "mdapp.h"

int
main()
{	
	/*LU decomposition*/
	
	int n,i,j;
	scanf("%d",&n);
	int pos[n];
	double A[n][n]/*,b[n],x[n]*/;
	for(i=0;i<n;i++){
		for(j=0;j<n;j++)
			scanf("%lf",&A[i][j]);
	}
	//for(i=0;i<n;i++)
	//	scanf("%lf",&b[i]);
	init_array(n,pos);
	ludcmp(n,A,pos);
	printmat(n,A,pos);
	print_int_array(n,pos);
	//lubksb(n,A,x,b,pos);
	//init_array(n,pos);
	//print_doub_array(n,x,pos);
	
	
	/*Thomas Algorithms*/

	/*int n,i,j;
	scanf("%d",&n);
	int pos[n];
	double A[3][n],b[n],x[n];
	for(j=0;j<n-1;j++)
		scanf("%lf",&A[0][j]);
	for(j=0;j<n;j++)
		scanf("%lf",&A[1][j]);
	for(j=1;j<n;j++)
		scanf("%lf",&A[2][j]);
	for(i=0;i<n;i++)
		scanf("%lf",&b[i]);
	init_array(n,pos);
	thomas(n,A,x,b);
	print_doub_array(n,x,pos);*/

	
	/*Cholesky Decomposition*/

	/*int n,i,j;
	scanf("%d",&n);
	int pos[n];
	double A[n][n];*/
	/*for(i=0;i<n;i++){
		for(j=0;j<n;j++)
			scanf("%lf",&A[i][j]);
	}*/
	/*hilb(n,A);
	init_array(n,pos);
	Chodcmp(n,A);
	printmat(n,A,pos);*/

	/*Householder*/

	/*int n,i,j;
	scanf("%d",&n);
	int pos[n];
	double P[n][n],x[n];
	for(i=0;i<n;i++)
		scanf("%lf", &x[i]);
	init_array(n,pos);
	householder(n,1,P,x);
	printmat(n,P,pos);
	print_doub_array(n,x,pos);*/

	/*QR by Householder*/

	/*int m,n,i,j;
	scanf("%d %d",&m,&n);
	int pos[n];
	double Q[n][n],A[n][n];
	for(i=0;i<n;i++){
		for(j=0;j<n;j++)
			scanf("%lf",&A[i][j]);
	}
	init_array(n,pos);
	qrdcmp(n,n,A,Q);
	printmat(n,Q,pos);
	printmat(n,A,pos);*/

   /*QR by Householder with pivoting*/

	/*int m,n,i,j;
	scanf("%d %d",&m,&n);
	int pos[n],pos1[m];
	double Q[m][m],A[m][n];*/
	/*for(i=0;i<m;i++){
		for(j=0;j<n;j++)
			scanf("%lf",&A[i][j]);
	}*/
	/*hilb(n,A);
	init_array(n,pos);
	init_array(m,pos1);
	qrdcmp_with_pivot(m,n,A,Q,pos);
	printmat(m,Q,pos1);
	printf("\n");
	for (i = 0; i < m; i++) {
	printf("| ");
	for (j = 0; j < n; j++) {
	   printf("%9.6f ", A[i][pos[j]]);
	}
		printf("|\n");
	}
	printf("\n");
	print_int_array(n,pos);*/

	/*Update QR decomposition*/

	/*int m,n,i,j;
	scanf("%d %d",&m,&n);
	int pos[n];
	double Q[n][n],A[n][n],s[n],t[n];
	for(i=0;i<n;i++){
		for(j=0;j<n;j++)
			scanf("%lf",&A[i][j]);
	}
	for(i=0;i<n;i++)
		scanf("%lf",&s[i]);
	for(i=0;i<n;i++)
		scanf("%lf",&t[i]);
	init_array(n,pos);
	qrdcmp(n,n,A,Q);
	qrupdt(n,n,Q,A,s,t);
	printmat(n,Q,pos);
	printmat(n,A,pos);*/

	/*Jocobi Method*/

	/*int n,i,j;
	scanf("%d",&n);
	int pos[n],ord[n];
	double A[n][n],V[n][n],ev[n];
	for(i=0;i<n;i++){
		for(j=0;j<n;j++)
			scanf("%lf",&A[i][j]);
	}
	init_array(n,pos);
	jocobi(n,A,V,ev);
	eigsrt(n,ev,ord);
	printmat(n,A,pos);
	printf("\n");
	printmat(n,V,pos);
	printf("\n");
	print_int_array(n,ord);*/

	/*test eigsrt*/

	/*int ord[8];
	double ev[]={3.14,15.9,6.26,4.27,18,28,180,38.8};
	eigsrt(8,ev,ord);
	print_int_array(8,ord);
	init_array(8,ord);
	print_doub_array(8,ev,ord);*/

	/*Singular Value Decomposition*/

	/*int m,n,i,j;
	scanf("%d%d",&m,&n);
	int pos1[m],pos2[n];
	double Ut[m][m],V[n][n],A[m][n],sv[n];*/
	/*for(i=0;i<m;i++){
		for(j=0;j<n;j++)
			scanf("%lf",&A[i][j]);
	}*/
	/*hilb(n,A);
	init_array(m,pos1);
	init_array(n,pos2);
	svd(m,n,A,Ut,V,sv);
	print_doub_array(n,sv,pos2);
	printf("\n");
	printmat(n,V,pos2);
	printf("\n");
	printmat(m,Ut,pos1);
	printf("%9.6f\n",sv[0]/sv[n-1]);*/

	/*SVD backsubstitution*/

	/*int m,n,i,j,rank;
	scanf("%d%d",&m,&n);
	int pos1[m],pos2[n];
	double Ut[m][m],V[n][n],A[m][n],sv[n],x[n],b[m];
	hilb(n,A);
	for(i=0;i<m;i++)
		scanf("%lf",&b[i]);
	init_array(n,pos2);
	rank=svd(m,n,A,Ut,V,sv);
	svbksb(m,n,rank,V,V,b,sv,x);
	print_doub_array(n,x,pos2);*/

	return 0;
}
